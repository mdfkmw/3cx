module.exports = {
  apps: [
    { name: "agent", script: "agent.js", cwd: "C:\\agent\\agent" },
    { name: "case",  script: "case.js",  cwd: "C:\\agent\\case"  },
    { name: "pos",   script: "pos.js",   cwd: "C:\\agent\\pos"   }
  ]
};
